from flask import Flask, render_template, request, redirect, url_for, jsonify, send_file
import subprocess
import os
import openai
import uuid
import csv

app = Flask(__name__)

# Configura tu clave API de OpenAI
openai.api_key = 'sk-proj-GNfzuz4X3JNFWjHL5mSQT3BlbkFJgfPQ1IJdZdMmiZ6nVpsV'

execution_results = []

@app.route('/')
def home():
    hosts = []
    try:
        with open('/app/hosts', 'r') as file:
            for line in file:
                if line.startswith("[targets]") or line.strip() == "":
                    hosts.append(line.strip())
                else:
                    parts = line.split()
                    if len(parts) > 0:
                        ip = parts[0]
                        hosts.append(ip)
    except Exception as e:
        print(f"Error al leer el archivo hosts: {e}")

    return render_template('index.html', hosts=hosts)

@app.route('/add-host', methods=['POST'])
def add_host():
    ip = request.form.get('ip')
    user = request.form.get('user')
    password = request.form.get('password')

    try:
        result = subprocess.run(['./scripts/add_host.sh', ip, user, password], capture_output=True, text=True)

        if result.returncode != 0:
            print(f"Failed to add host: {result.stderr}")
            return f"Error: {result.stderr}", 500

        print(f"Script executed successfully for IP: {ip}")
    except subprocess.CalledProcessError as e:
        print(f"Failed to execute script: {e}")
        return f"Error: {e}"

    return redirect(url_for('home'))

@app.route('/remove-host', methods=['POST'])
def remove_host():
    ip_remove = request.form.get('ip')

    try:
        result = subprocess.run(['python3', './scripts/remove_hosts.py', ip_remove], check=True)
        print(f"Script executed successfully for IP: {ip_remove}")
    except subprocess.CalledProcessError as e:
        print(f"Failed to execute removal script: {e}")
        return f"Error: {e}", 500

    return redirect(url_for('home'))

@app.route('/ansible')
def ansible():
    return render_template('ansible.html')

@app.route('/generate-playbook', methods=['POST'])
def generate_playbook():
    instruction = request.json.get('instruction')

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "Eres experto en Ansible playbooks."},
                {"role": "user", "content": f"Genera un playbook con la siguiente instrucción: {instruction}. Usa 'hosts: targets' para los hosts group, además cada que agregues comentarios de lo que hace el playbook, agrega a tus comentarios un símbolo de # de acuerdo con cada salto de línea, evita colocárselo a las líneas que hacen funcionar el playbook, evita agregar explicaciones al final de que hace el playbook."}
            ]
        )
        playbook = response['choices'][0]['message']['content'].strip()

        # Asegurar que el playbook generado use 'hosts: targets'
        playbook = playbook.replace('hosts: all', 'hosts: targets')
        playbook = playbook.replace('hosts: web_servers', 'hosts: targets')  # Example replacement, adjust as needed

        return jsonify(playbook=playbook)
    except Exception as e:
        return jsonify(error=str(e)), 500

@app.route('/save-playbook', methods=['POST'])
def save_playbook():
    playbook = request.json.get('playbook')

    # Procesar el playbook para eliminar líneas no deseadas y convertir comentarios
    lines = playbook.split('\n')
    clean_lines = []
    inside_playbook = False
    playbook_name = "playbook_" + uuid.uuid4().hex  # Default name if no name found

    for line in lines:
        stripped_line = line.strip()
        if stripped_line.startswith('- name:'):  # Marca el inicio del playbook y toma el nombre
            inside_playbook = True
            playbook_name = stripped_line.split(':', 1)[1].strip().replace(" ", "_").lower()

        if inside_playbook:
            # Ignorar líneas de markdown y comentarios adicionales de ChatGPT
            if stripped_line.startswith('```'):
                continue
            clean_lines.append(line)
        elif stripped_line:  # Comentamos solo si la línea no está vacía
            clean_lines.append('# ' + line)

    clean_playbook = '\n'.join(clean_lines)

    # Generar un nombre de archivo único basado en el nombre del playbook
    filename = f"{playbook_name}.yml"
    file_path = os.path.join('/app/scripts/playbooks', filename)

    try:
        # Guardar el playbook en el archivo
        with open(file_path, 'w') as file:
            file.write(clean_playbook)

        return jsonify(filename=filename)
    except Exception as e:
        return jsonify(error=str(e)), 500

@app.route('/playbooks', methods=['GET'])
def get_playbooks():
    playbooks = []
    try:
        for filename in os.listdir('/app/scripts/playbooks'):
            if filename.endswith('.yml'):
                playbooks.append(filename)
    except Exception as e:
        return jsonify(error=str(e)), 500
    return jsonify(playbooks=playbooks)

@app.route('/run-playbook', methods=['POST'])
def run_playbook():
    playbook = request.json.get('playbook')

    try:
        result = subprocess.run(['ansible-playbook', '-i', '/app/hosts', f'/app/scripts/playbooks/{playbook}'], capture_output=True, text=True)

        if result.returncode != 0:
            return jsonify(error=result.stderr), 500

        # Guardar el resultado de la ejecución para la página de resultados
        global execution_results
        execution_results = result.stdout.split('\n')

        return jsonify(output=result.stdout)
    except subprocess.CalledProcessError as e:
        return jsonify(error=str(e)), 500

@app.route('/results')
def results():
    return render_template('results.html', results=execution_results)

@app.route('/export-results')
def export_results():
    filepath = '/app/scripts/playbooks/execution_results.csv'
    try:
        with open(filepath, 'w', newline='') as csvfile:
            csvwriter = csv.writer(csvfile)
            csvwriter.writerow(['Output'])
            for line in execution_results:
                csvwriter.writerow([line])

        return send_file(filepath, as_attachment=True)
    except Exception as e:
        return jsonify(error=str(e)), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

