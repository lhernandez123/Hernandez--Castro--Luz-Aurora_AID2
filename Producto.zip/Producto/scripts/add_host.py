import sys
import paramiko
import os

def add_host(ip, user, password):
    # Crear un cliente SSH
    client = paramiko.SSHClient()
    # Agregar automáticamente nuevas claves host
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        # Conectarse al servidor remoto
        client.connect(hostname=ip, username=user, password=password)

        # Crear el directorio .ssh en el servidor remoto
        stdin, stdout, stderr = client.exec_command('mkdir -p /root/.ssh && chmod 700 /root/.ssh')
        stdout.channel.recv_exit_status()  # Esperar a que el comando termine

        # Leer la clave pública de la máquina local
        with open('/root/.ssh/id_rsa.pub', 'r') as pubkey_file:
            pubkey = pubkey_file.read().strip()

        # Agregar la clave pública al archivo authorized_keys en el servidor remoto
        stdin, stdout, stderr = client.exec_command(f'echo "{pubkey}" >> /root/.ssh/authorized_keys && chmod 600 /root/.ssh/authorized_keys')
        stdout.channel.recv_exit_status()  # Esperar a que el comando termine

        print(f"Host {ip} configurado exitosamente.")
    except Exception as e:
        print(f"Error al configurar el host {ip}: {e}")
    finally:
        client.close()

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: add_host.py <ip> <user> <password>")
        sys.exit(1)

    ip = sys.argv[1]
    user = sys.argv[2]
    password = sys.argv[3]

    # Añadir el host a known_hosts
    known_hosts_file = '/root/.ssh/known_hosts'
    ssh_keyscan_command = f"ssh-keyscan -H {ip} >> {known_hosts_file}"

    os.system(ssh_keyscan_command)
    
    add_host(ip, user, password)

