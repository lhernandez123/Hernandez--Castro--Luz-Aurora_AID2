#!/bin/bash

# Variables
HOST_IP=$1
HOST_USER=$2
HOST_PASS=$3

# Ejecutar el script de Python para agregar la IP al inventario y configurar la clave SSH
python3 scripts/add_host.py $HOST_IP $HOST_USER $HOST_PASS

# Verificar si el script de Python fue exitoso
if [ $? -eq 0 ]; then
  # Llamar al script create_hosts.py para agregar la IP al archivo de hosts
  python3 scripts/create_hosts.py $HOST_IP $HOST_USER $HOST_PASS
else
  echo "Error: No se pudo agregar el host $HOST_IP."
  exit 1
fi

